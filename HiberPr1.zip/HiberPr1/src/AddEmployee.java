import org.hibernate.Transaction;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.emp.Employee;

public class AddEmployee
{
	public static void main(String[] args)
	{
		Session session = null;
		SessionFactory factory;
		try
		{
			//String[] arg=new String[3];
			factory=new Configuration().configure().buildSessionFactory();
			session=factory.openSession();

			Transaction tr=session.beginTransaction();
			
			/*args[0]="2";
			args[2]="20000";
			args[1]="aaa";
			int id=Integer.parseInt(args[0]);
			int sl=Integer.parseInt(args[2]);
*/
			Employee emp=new Employee(3,"xyz",50000);
			session.save(emp);
			tr.commit();
			System.out.println("Record Added");

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			session.flush();
			session.close();
		}
	}
}