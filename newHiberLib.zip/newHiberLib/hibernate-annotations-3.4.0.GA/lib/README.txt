Hibernate Annotations dependencies
==================================


Core
====
hibernate-commons-annotations.jar: required
hibernate3.jar: required
hibernate core dependencies: required (see Hibernate Core for more information)
ejb3-persistence.jar: required
hibernate-validator.jar: optional
hibernate-search.jar: optional

Test
====
(no additinal dependency)